package Model;

import java.util.ArrayList;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Vector3f;

public class Nave {

	Camara camara;
	private String modelo;
	private float velocidad;
	private String textura;
	private ArrayList<Vector3f> posiciones;
	private ArrayList<Vector3f> angulos;

	/**
	 * 
	 * @param modelo
	 * @param textura
	 * @param velocidad
	 */
	public Nave(String modelo, String textura, float velocidad) {
		// TODO - implement Nave.Nave
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param posicion
	 * @param angulo
	 */
	public void addEstado(Vector3f posicion, Vector3f angulo) {
		// TODO - implement Nave.addEstado
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param textura
	 */
	public void setTextura(String textura) {
		this.textura = textura;
	}

	/**
	 * 
	 * @param vel
	 */
	public void setVelocidad(long vel) {
		// TODO - implement Nave.setVelocidad
		throw new UnsupportedOperationException();
	}

	public BranchGroup dibujar() {
		// TODO - implement Nave.dibujar
		throw new UnsupportedOperationException();
	}

	private TransformGroup transformar() {
		// TODO - implement Nave.transformar
		throw new UnsupportedOperationException();
	}

}