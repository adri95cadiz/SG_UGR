package Model;

public class Escena extends BranchGroup {

	/**
	 * 
	 * @param astro
	 */
	public void addAstro(Astro astro) {
		// TODO - implement Escena.addAstro
		throw new UnsupportedOperationException();
	}

	public Nave getNave() {
		// TODO - implement Escena.getNave
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nave
	 */
	public void setNave(Nave nave) {
		// TODO - implement Escena.setNave
		throw new UnsupportedOperationException();
	}

}