package Model;

public class BranchGroup {
}