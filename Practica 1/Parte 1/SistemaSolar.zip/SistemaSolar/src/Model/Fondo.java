package Model;

public class Fondo extends BranchGroup {

	private String textura;

	/**
	 * 
	 * @param textura
	 */
	public Fondo(String textura) {
		// TODO - implement Fondo.Fondo
		throw new UnsupportedOperationException();
	}

}