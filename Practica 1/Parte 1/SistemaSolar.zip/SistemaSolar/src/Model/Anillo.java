package Model;

public class Anillo {

	private float radioInterno;
	private float radioExterno;
	private String textura;

	/**
	 * 
	 * @param radioExterno
	 * @param radioInterno
	 * @param textura
	 */
	public Anillo(float radioExterno, float radioInterno, String textura) {
		// TODO - implement Anillo.Anillo
		throw new UnsupportedOperationException();
	}

	public BranchGroup dibujar() {
		// TODO - implement Anillo.dibujar
		throw new UnsupportedOperationException();
	}

}