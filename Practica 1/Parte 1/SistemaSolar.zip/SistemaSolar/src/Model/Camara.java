package Model;

import javax.vecmath.Vector3f;

public class Camara {

	private Vector3f posicion;
	private Vector3f direccion;
	private float planoDel;
	private float planoTras;
	private float anguloAper;

	/**
	 * 
	 * @param posicion
	 * @param direccion
	 * @param planoDel
	 * @param planoTras
	 * @param anguloAper
	 */
	public Camara(Vector3f posicion, Vector3f direccion, float planoDel, float planoTras, float anguloAper) {
		// TODO - implement Camara.Camara
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param pos
	 */
	public void setPosicion(Vector3f pos) {
		this.posicion = pos;
	}

	/**
	 * 
	 * @param dir
	 */
	public void setDireccion(Vector3f dir) {
		this.direccion = dir;
	}

}