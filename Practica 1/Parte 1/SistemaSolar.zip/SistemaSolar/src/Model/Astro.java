package Model;

import java.util.*;
import javax.media.j3d.RotationInterpolator;
import javax.media.j3d.TransformGroup;
        
public class Astro {

	Collection<Anillo> anillos;
	Collection<Astro> satelites;
	Camara camara;
	private float diametro;
	private long velOrbita;
	private long velRotacion;
	private float disOrbita;
	private String textura;
	private RotationInterpolator rotator;
	private RotationInterpolator rotatorAround;

	/**
	 * 
	 * @param diametro
	 * @param velOrbita
	 * @param velRotacion
	 * @param disOrbita
	 * @param textura
	 */
	public Astro(float diametro, long velOrbita, long velRotacion, float disOrbita, String textura) {
		// TODO - implement Astro.Astro
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param camara
	 */
	public void setCamara(Camara camara) {
		this.camara = camara;
	}

	/**
	 * 
	 * @param astro
	 */
	public void addSatelite(Astro astro) {
		// TODO - implement Astro.addSatelite
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param anillo
	 */
	public void addAnillo(Anillo anillo) {
		// TODO - implement Astro.addAnillo
		throw new UnsupportedOperationException();
	}

	public BranchGroup dibujar() {
		// TODO - implement Astro.dibujar
		throw new UnsupportedOperationException();
	}

	private TransformGroup rotar() {
		// TODO - implement Astro.rotar
		throw new UnsupportedOperationException();
	}

	private TransformGroup rotarAlrededor() {
		// TODO - implement Astro.rotarAlrededor
		throw new UnsupportedOperationException();
	}

	private TransformGroup trasladar() {
		// TODO - implement Astro.trasladar
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param vel
	 */
	public void setVelRotacion(long vel) {
		this.velRotacion = vel;
	}

	/**
	 * 
	 * @param vel
	 */
	public void setVelOrbita(long vel) {
		this.velOrbita = vel;
	}

	/**
	 * 
	 * @param dis
	 */
	public void setDisOrbita(float dis) {
		this.disOrbita = dis;
	}

	/**
	 * 
	 * @param textura
	 */
	public void setTextura(String textura) {
		this.textura = textura;
	}

}