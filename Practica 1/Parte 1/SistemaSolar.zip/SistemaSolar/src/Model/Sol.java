package Model;

public class Sol extends Astro {

	Luz luz;

	/**
	 * 
	 * @param diametro
	 * @param textura
	 * @param luz
	 */
	public Sol(float diametro, String textura, Luz luz) {
		// TODO - implement Sol.Sol
                super(diametro, 0, 0, 0, textura);
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param luz
	 */
	public void setLuz(Luz luz) {
		this.luz = luz;
	}

}