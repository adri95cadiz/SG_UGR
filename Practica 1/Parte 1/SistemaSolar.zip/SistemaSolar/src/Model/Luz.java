package Model;

public class Luz {

	private float especular;
	private float ambiental;
	private float difusa;
	private float brillo;

	/**
	 * 
	 * @param especular
	 * @param ambiental
	 * @param difusa
	 * @param brillo
	 */
	public Luz(float especular, float ambiental, float difusa, float brillo) {
		// TODO - implement Luz.Luz
		throw new UnsupportedOperationException();
	}

}