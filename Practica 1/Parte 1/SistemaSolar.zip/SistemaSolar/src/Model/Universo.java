package Model;

import com.sun.j3d.utils.universe.SimpleUniverse;
import javax.media.j3d.Canvas3D;

public class Universo {

	Fondo fondo;
	Camara camara;
	Escena escena;

	/**
	 * 
	 * @param canvas
	 */
	public Universo(Canvas3D canvas) {
		// TODO - implement Universo.Universo
		throw new UnsupportedOperationException();
	}

	public void close() {
		// TODO - implement Universo.close
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param canvas
         * @return 
	 */
	public SimpleUniverse createUniverse(Canvas3D canvas) {
		// TODO - implement Universo.createUniverse
		throw new UnsupportedOperationException();
	}

}